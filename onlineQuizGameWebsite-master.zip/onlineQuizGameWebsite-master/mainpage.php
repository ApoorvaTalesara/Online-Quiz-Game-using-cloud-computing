<!DOCTYPE html>

<head>
    <title>MIZA Quiz</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
</head>
<style>

html,body{
    height:100%;
}
*{
    box-sizing:border-box;
    margin:0;
    padding:0;
    outline:none;
}
    .navbar {
        background-color: black;
        height: 80px;
        width:100%;
        padding-top:20px;

    }
    .heading{
        margin-top: 5%;
        margin-left: 15%;
        margin-left:33%;

    }
    .login {
        padding: 12px;
        margin-left: 85%;
        font-size: 27px;
        color: beige;
        margin-top:25px;
    }

    .register {
        font-size: 27px;
        color: beige;
        margin-top:15px;
    }

    .box {
        margin-top: 5%;
        margin-left: 750px;
        font-size: 30px;
    }

    .quiz {
        padding: 20px;
        background-color: rgb(5, 5, 5);
        color: beige;
    }

    .quit {
        padding: 20px;
        background-color: rgb(5, 5, 5);
        color: beige;
    }

    body {
    height: 100%;
    width:100%;
    background: url("bg1.jpeg");
    background-position: center;
    background-size:cover;
    background-repeat:no-repeat;
    }
</style>

<body>
    <div class="navbar">

        <a style="text-decoration:none;" href="re-login.php" class="login">Login</a>
        <a style="text-decoration:none;" href="re-login.php" class="register">Register</a>
        <?php 


        if(!(isset($_SESSION["login"]) && $_SESSION["login"] == "OK")) {

            ?>
            <!-- <li><a href="reglogin.php">Account</a></li> -->
    
            <?php
        }

        else{
            echo "Welcome, ";
            echo $_SESSION['username'];?>
            <li><a href="logout.php">logout</a></li>


            <?php
        }
        ?>  
    </div>
    <div class="heading">
    <p style="font-size: 50px;padding:20px; text-align=center;">Welcome to MIZA Quiz!!!</p>
    </div>
    <div class="box">

        <a style="text-decoration:none;" href="index.php" class="quiz">Take Quiz</a>
        <!--<a style="text-decoration:none;" href="endpg.php" class="quit">Quit</a>-->

    </div>
</body>