<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quiz app</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<?php 
session_start();

if(!(isset($_SESSION["login"]) && $_SESSION["login"] == "OK")) {
    header('location:re-login.php');
    ?><li><a href="reglogin.php">Account</a></li>

    <?php
}

else{
   ?> 
   <center><h1 style="margin-top:1%"><?php echo "Welcome ". $_SESSION['username'];?></h1> </center>
    
    <button type="button" class="btn" style="float:right;margin:10px;background-color:black;font-size:30px;"><a href="logout.php" style="text-decoration:none;color:white;">Logout</a></button>


    <?php
}
?>  
    <div class="home-box custom-box ">
        <h3>Instructions:</h3>
        <p>Total number of questions: <span class="total-question">10</span></p>
        <button type="button" class="btn"  onclick="startQuiz()">Start Quiz</button>
    </div>

    <div class="quiz-box custom-box  hide">
        <div class="question-number">
            
        </div>
        <div class="question-text">
           
        </div>
        <div class="option-container ">
            
        </div>
        <div class="next-question-btn"><button type="button" class="btn" onclick="next()">Next</button></div>
        <div class="answers-indicators">
            
        </div>
    </div>
    <div class="result-box custom-box hide">
        <h1>Quiz Result</h1>
        <table>
            <tr>
                <td>Total Questions</td>
                <td><span class="total-question"></span></td>
            </tr>
            <tr>
                <td>Attempt</td>
                <td><span class="total-attempt"></span></td>
            </tr>
            <tr>
                <td>Correct</td>
                <td><span class="total-correct"></span></td>
            </tr>
            <tr>
                <td>Wrong</td>
                <td><span class="total-wrong"></span></td>
            </tr>
            <tr>
                <td>Percentage</td>
                <td><span class="percentage"></span></td>
            </tr>
            <tr>
                <td>Your Total Score</td>
                <td><span class="total-score"></span></td>
            </tr>
        </table>
        
        <button type="button" class="btn"> <a style ="text-decoartion:none;"href = "mainpage.php">Go To Home </a>  </button>
    </div>
    <script src="js/question.js"></script>
    <script src="js/app1.js"></script>
</body>
</html>