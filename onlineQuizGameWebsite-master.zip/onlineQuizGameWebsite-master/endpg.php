<!DOCTYPE html>

<head>
    <title>Trivia Quiz</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
</head>
<style>
    body {
        /* height: auto;
        width: fit-content; */
        background: url('bg1.jpeg');
        background-repeat:no-repeat;
        /* background-position:center; */
        background-size:cover;
    }

    .end {
        padding: 10px;
        height: 51px;
        width: 250px;
        font-size: 40px;
        color: white;
        background-color:black;
        margin-top: 20%;
        margin-left: 45%;
    }
</style>

<body>
    <!-- <img src="bg.jpg"> -->
    <div class="end">!!Thank You!!</div>

</body>