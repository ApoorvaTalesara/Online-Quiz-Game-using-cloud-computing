//array of objects
const quiz=[
    {
        q:'HTML is what type of language?',
        options:['Scripting Language','Markup Language','Programming Language','Network Protocol'],
            
    
        answer:0
    },

    {
        q:'HTML uses?',
        options:['User defined tags','Pre-specified tags','Fixed tags defined by the language','Tags only for linking'],
            
    
        answer:2
    },

    {
        q:'The year in which HTML was first proposed _______.?',
        options:['1990','1980','2000','1995'],
            
    
        answer:0
    },

    {
        q:'Fundamental HTML Block is known as ___________.?',
        options:['HTML Body','HTML Tag','HTML Attribute','HTML Element'],
            
    
        answer:1
    },

    {
       q:' CSS stands for?' ,

       options:['Cascade style sheets','Color and style sheets','Cascading style sheets','None of the these'] ,
        
        
        
            
    
        answer:2
    },

    {
        q:'What is the full form of HTML?',
        options:['HyperText Markup Language','Hyper Teach Markup Language','Hyper Tech Markup Language','None of these'],
            
    
        answer:0
    },

    {
        q:'Who is Known as the father of World Wide Web (WWW)?',
        
        options:['Robert Cailliau','Tim Thompson','Charles Darwin','Tim Berners-Lee'],
    
        answer:3
    },

    {
        q:'The CSS property used to control the element font-size is?',
        options:['text-style','text-size','font-size','None of the these'],
            
    
        answer:2
    },

    {
        q:'The HTML attribute used to define the inline styles is?',
        options:['Style','Styles','Class','None of the these'],
            
    
        answer:0
    },

    {
        q:'What tag is used to display a picture in a HTML page?',
        options:['picture','image','img','src'],
            
    
        answer:2
    },
]